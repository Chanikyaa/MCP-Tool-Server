"""SDK-level protocol tests, run automatically when the official MCP SDK is installed."""
from __future__ import annotations

import pytest

mcp = pytest.importorskip("mcp")


@pytest.mark.asyncio
async def test_server_registers_expected_tools_and_protocol_call() -> None:
    from mcp import Client
    from mcp_tool_server.server import mcp as server

    async with Client(server) as client:
        listed = await client.list_tools()
        names = {tool.name for tool in listed.tools}
        assert {
            "search_documents_tool",
            "get_document_metadata",
            "calculate",
            "query_structured_data",
        } <= names

        result = await client.call_tool("calculate", {"expression": "(12 + 8) * 3"})
        assert result.is_error is False
        assert any("60" in getattr(block, "text", "") for block in result.content)


@pytest.mark.asyncio
async def test_server_exposes_resource_and_prompt() -> None:
    from mcp import Client
    from mcp_tool_server.server import mcp as server

    async with Client(server) as client:
        resources = await client.list_resources()
        assert any(str(resource.uri) == "catalog://summary" for resource in resources.resources)
        prompts = await client.list_prompts()
        assert any(prompt.name == "research_documents" for prompt in prompts.prompts)
