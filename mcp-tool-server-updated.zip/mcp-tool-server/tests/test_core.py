from __future__ import annotations

from pathlib import Path

import pytest

from mcp_tool_server.core import (
    catalog_summary,
    document_metadata,
    query_catalog,
    safe_calculate,
    search_documents,
)

DATA = Path(__file__).resolve().parents[1] / "data"


def test_search_documents_returns_source_and_snippet() -> None:
    result = search_documents("retrieval evidence citation", DATA, 3)
    assert result["results"]
    assert all(item["source"].endswith(".md") for item in result["results"])
    assert all(item["snippet"] for item in result["results"])


def test_search_rejects_blank_and_oversized_query() -> None:
    with pytest.raises(ValueError):
        search_documents("  ", DATA)
    with pytest.raises(ValueError):
        search_documents("x" * 301, DATA)


def test_document_metadata_found_and_not_found() -> None:
    assert document_metadata("rag-basics", DATA)["title"] == "Retrieval-Augmented Generation Basics"
    with pytest.raises(LookupError):
        document_metadata("does-not-exist", DATA)


def test_calculator_basic_expression() -> None:
    assert safe_calculate("(12 + 8) * 3")["result"] == 60
    assert safe_calculate("2 ** 3")["result"] == 8


@pytest.mark.parametrize("expression", [
    "__import__('os').system('echo unsafe')",
    "open('/etc/passwd').read()",
    "1 / 0",
    "2 ** 100",
    "x + 1",
])
def test_calculator_rejects_unsafe_or_invalid_expression(expression: str) -> None:
    with pytest.raises(ValueError):
        safe_calculate(expression)


def test_catalog_query_is_allowlisted_and_parameterized() -> None:
    result = query_catalog("projects", "domain", "ai-infrastructure", DATA)
    assert result["count"] == 1
    assert result["rows"][0]["project_id"] == "p3"
    with pytest.raises(ValueError):
        query_catalog("projects; DROP TABLE skills", "name", None, DATA)
    with pytest.raises(ValueError):
        query_catalog("projects", "name; DROP TABLE skills", None, DATA)


def test_catalog_summary_is_read_only_summary() -> None:
    result = catalog_summary(DATA)
    assert result["access"] == "read-only"
    assert result["datasets"]["projects"] >= 1
