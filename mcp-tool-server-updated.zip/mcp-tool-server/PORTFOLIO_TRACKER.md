# Portfolio tracker entry — Project 3

| Field | Status |
|---|---|
| Project | MCP Tool Server (`mcp-tool-server`) |
| Target roles | AI Engineer, Applied AI Engineer, AI Platform / Tooling Engineer |
| Core technologies | Python, official MCP SDK v2, SQLite, pytest |
| Implementation | MVP source and sample data created |
| Core test status | Pending execution in current runtime |
| Protocol test status | Not yet verified; requires MCP SDK installation and client/Inspector run |
| Evaluation status | Not applicable as a model benchmark; tool behavior tests are included |
| Deployment status | Local stdio / loopback HTTP design; not deployed |
| GitHub publication | Not published |
| Next steps | Run tests; install SDK; verify protocol client; run Ruff/mypy; inspect and publish |
