"""Rebuild the small synthetic catalog database."""

from __future__ import annotations

import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "catalog.sqlite3"


def main() -> None:
    if DB_PATH.exists():
        DB_PATH.unlink()
    connection = sqlite3.connect(DB_PATH)
    try:
        connection.executescript(
            """
            CREATE TABLE projects (
                project_id TEXT PRIMARY KEY, name TEXT NOT NULL, domain TEXT NOT NULL,
                status TEXT NOT NULL, difficulty INTEGER NOT NULL CHECK(difficulty BETWEEN 1 AND 5)
            );
            CREATE TABLE skills (
                skill_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, level TEXT NOT NULL
            );
            """
        )
        connection.executemany(
            "INSERT INTO projects VALUES (?, ?, ?, ?, ?)",
            [
                ("p1", "Hybrid Search RAG", "generative-ai", "planned", 3),
                ("p2", "LLM Evaluation Lab", "evaluation", "planned", 3),
                ("p3", "MCP Tool Server", "ai-infrastructure", "in-progress", 3),
                ("p8", "End-to-End Classical ML", "machine-learning", "planned", 3),
            ],
        )
        connection.executemany(
            "INSERT INTO skills VALUES (?, ?, ?, ?)",
            [
                ("s1", "Python", "programming", "intermediate"),
                ("s2", "Model Context Protocol", "ai-infrastructure", "beginner"),
                ("s3", "Automated Testing", "software-engineering", "intermediate"),
                ("s4", "SQL", "data-engineering", "beginner"),
            ],
        )
        connection.commit()
    finally:
        connection.close()
    print(f"Rebuilt {DB_PATH}")


if __name__ == "__main__":
    main()
