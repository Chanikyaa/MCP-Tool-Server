#!/usr/bin/env sh
set -eu
export MCP_TRANSPORT=streamable-http
export MCP_HOST=127.0.0.1
export MCP_PORT=8000
printf '%s\n' 'Start the server in one terminal with:' '  MCP_TRANSPORT=streamable-http MCP_HOST=127.0.0.1 MCP_PORT=8000 mcp-tool-server' 'Then run in another terminal:' '  MCP_SERVER_URL=http://127.0.0.1:8000/mcp mcp-tool-client-demo'
