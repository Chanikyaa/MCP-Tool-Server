# MCP Server Security Notes

The Model Context Protocol standardizes how an AI application discovers and calls tools, reads resources, and retrieves prompts. An MCP server is not simply a REST endpoint: it implements protocol messages and capabilities through an MCP SDK and supported transport.

Tool inputs must be validated and bounded. Prefer least-privilege access and read-only data operations. Do not expose arbitrary shell execution or unrestricted SQL to a model. Structured database queries should use an allowlist of tables and fields and parameterized values.

The stdio transport is useful for a local client that launches the server as a subprocess. Streamable HTTP is suitable for HTTP-connected clients, but a remotely reachable deployment needs an explicit authentication and authorization design. This sample binds HTTP to loopback only and does not claim to implement remote authentication.

Tool output is untrusted too. Clients should review tool behavior, validate returned data, and require user approval before sensitive or irreversible actions.
