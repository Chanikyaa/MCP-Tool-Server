# Retrieval-Augmented Generation Basics

Retrieval-augmented generation (RAG) combines information retrieval with a language model. A typical system ingests documents, splits them into chunks, retrieves relevant passages for a question, and generates an answer grounded in those passages.

Useful evaluation separates retrieval quality from answer quality. Recall@k measures whether relevant evidence appears in the top k retrieved items. Mean reciprocal rank rewards placing the first relevant result near the top. Citation checks should verify that cited passages actually support the associated claims.

Retrieved documents are untrusted input. A document may contain malicious instructions or irrelevant content. Systems should treat such content as evidence, not as higher-priority instructions, and should abstain when the available evidence is insufficient.
