# Machine Learning Evaluation Principles

An evaluation dataset should separate development examples from a held-out test set. Tune choices on development data and use the held-out set for final reporting. Keep datasets versioned and record the configuration used for each experiment.

A useful report includes aggregate metrics and per-example failures. Aggregate scores can hide systematic failures, so inspect incorrect examples, missing evidence, data leakage, and differences between slices. Reproducible baselines make it easier to decide whether a change actually improves a system.
