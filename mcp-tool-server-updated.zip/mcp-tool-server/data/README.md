# Data and licensing

The Markdown files and SQLite catalog in this directory are original synthetic examples created for this portfolio project. They contain no employer, customer, or personal data. They may be reused under the repository's MIT license. Replace them only with public or properly licensed materials and record each source's license before publishing.

`catalog.sqlite3` contains the same small synthetic records as the SQL seed in `scripts/seed_catalog.py`. It is opened in SQLite read-only mode by application code. To recreate it, run `python scripts/seed_catalog.py`.
