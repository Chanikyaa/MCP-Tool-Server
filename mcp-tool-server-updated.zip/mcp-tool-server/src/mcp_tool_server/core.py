"""Pure business logic for the MCP server; intentionally independent of the SDK."""

from __future__ import annotations

import ast
import json
import logging
import math
import operator
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

LOGGER = logging.getLogger(__name__)
MAX_QUERY_LENGTH = 300
MAX_SEARCH_RESULTS = 10
MAX_EXPRESSION_LENGTH = 120
MAX_AST_NODES = 40


@dataclass(frozen=True, slots=True)
class Document:
    """A small document record used by the example search index."""

    doc_id: str
    title: str
    path: str
    text: str
    category: str


def load_documents(data_dir: Path) -> list[Document]:
    """Load bundled Markdown documents with stable IDs and bounded file sizes."""
    docs_dir = data_dir / "documents"
    documents: list[Document] = []
    if not docs_dir.exists():
        return documents
    for path in sorted(docs_dir.glob("*.md")):
        if not path.is_file() or path.stat().st_size > 256_000:
            LOGGER.warning("Skipping unsupported or oversized document: %s", path.name)
            continue
        text = path.read_text(encoding="utf-8")
        title = next((line.lstrip("# ").strip() for line in text.splitlines() if line.startswith("#")), path.stem)
        documents.append(
            Document(
                doc_id=path.stem,
                title=title[:200],
                path=path.name,
                text=text[:50_000],
                category=path.stem.split("-")[0],
            )
        )
    return documents


def search_documents(query: str, data_dir: Path, limit: int = 5) -> dict[str, Any]:
    """Search local Markdown by normalized token overlap; no external network access."""
    normalized = query.strip()
    if not normalized or len(normalized) > MAX_QUERY_LENGTH:
        raise ValueError(f"query must contain 1–{MAX_QUERY_LENGTH} characters")
    if not 1 <= limit <= MAX_SEARCH_RESULTS:
        raise ValueError(f"limit must be between 1 and {MAX_SEARCH_RESULTS}")
    query_terms = {token.lower() for token in _tokens(normalized)}
    if not query_terms:
        return {"query": normalized, "results": []}

    results: list[dict[str, Any]] = []
    for doc in load_documents(data_dir):
        terms = [token.lower() for token in _tokens(doc.text)]
        if not terms:
            continue
        counts = {term: terms.count(term) for term in query_terms}
        overlap = sum(count > 0 for count in counts.values())
        if overlap == 0:
            continue
        score = overlap / math.sqrt(len(query_terms) * len(set(terms)))
        first_hit = min((doc.text.lower().find(term) for term in query_terms if term in doc.text.lower()), default=0)
        start = max(0, first_hit - 100)
        snippet = " ".join(doc.text[start : start + 450].split())
        results.append(
            {
                "document_id": doc.doc_id,
                "title": doc.title,
                "source": doc.path,
                "category": doc.category,
                "score": round(score, 4),
                "snippet": snippet,
            }
        )
    results.sort(key=lambda item: (-item["score"], item["document_id"]))
    return {"query": normalized, "results": results[:limit]}


def document_metadata(document_id: str, data_dir: Path) -> dict[str, Any]:
    """Return metadata only for documents present in the configured corpus."""
    if not document_id or len(document_id) > 100 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in document_id):
        raise ValueError("document_id contains unsupported characters")
    for doc in load_documents(data_dir):
        if doc.doc_id == document_id:
            return {
                "document_id": doc.doc_id,
                "title": doc.title,
                "source": doc.path,
                "category": doc.category,
                "character_count": len(doc.text),
            }
    raise LookupError(f"No document found for id '{document_id}'")


def safe_calculate(expression: str) -> dict[str, Any]:
    """Evaluate a small arithmetic grammar without eval/exec or arbitrary names."""
    if not expression.strip() or len(expression) > MAX_EXPRESSION_LENGTH:
        raise ValueError(f"expression must contain 1–{MAX_EXPRESSION_LENGTH} characters")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ValueError("expression is not valid arithmetic") from exc
    if sum(1 for _ in ast.walk(tree)) > MAX_AST_NODES:
        raise ValueError("expression is too complex")

    binary_ops = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
    }
    unary_ops = {ast.UAdd: operator.pos, ast.USub: operator.neg}

    def visit(node: ast.AST) -> float | int:
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            value = node.value
            if abs(value) > 1_000_000_000:
                raise ValueError("numeric literal exceeds supported magnitude")
            return value
        if isinstance(node, ast.BinOp) and type(node.op) in binary_ops:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 10:
                raise ValueError("exponent magnitude must be at most 10")
            result = binary_ops[type(node.op)](left, right)
            if not math.isfinite(float(result)) or abs(result) > 1e15:
                raise ValueError("result exceeds supported numeric range")
            return result
        if isinstance(node, ast.UnaryOp) and type(node.op) in unary_ops:
            return unary_ops[type(node.op)](visit(node.operand))
        raise ValueError("only numeric literals and +, -, *, /, //, %, **, unary +/- are allowed")

    try:
        result = visit(tree)
    except ZeroDivisionError as exc:
        raise ValueError("division by zero is not allowed") from exc
    if isinstance(result, float) and result.is_integer():
        result = int(result)
    return {"expression": expression, "result": result}


ALLOWED_FIELDS: dict[str, tuple[str, ...]] = {
    "projects": ("project_id", "name", "domain", "status", "difficulty"),
    "skills": ("skill_id", "name", "category", "level"),
}


def query_catalog(
    dataset: str,
    field: str,
    value: str | None,
    data_dir: Path,
    limit: int = 10,
) -> dict[str, Any]:
    """Query fixed allowlisted catalog fields using parameterized SQL and read-only mode."""
    if dataset not in ALLOWED_FIELDS:
        raise ValueError(f"dataset must be one of: {', '.join(ALLOWED_FIELDS)}")
    if field not in ALLOWED_FIELDS[dataset]:
        raise ValueError(f"field must be one of: {', '.join(ALLOWED_FIELDS[dataset])}")
    if value is not None and len(value) > 200:
        raise ValueError("filter value must be at most 200 characters")
    if not 1 <= limit <= 50:
        raise ValueError("limit must be between 1 and 50")

    db_path = (data_dir / "catalog.sqlite3").resolve()
    if not db_path.exists():
        raise FileNotFoundError(f"catalog database not found: {db_path}")
    connection = sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True, timeout=2.0)
    connection.row_factory = sqlite3.Row
    try:
        columns = ", ".join(ALLOWED_FIELDS[dataset])
        sql = f"SELECT {columns} FROM {dataset}"
        params: list[Any] = []
        if value is not None:
            sql += f" WHERE {field} = ? COLLATE NOCASE"
            params.append(value)
        sql += " ORDER BY 1 LIMIT ?"
        params.append(limit)
        rows = connection.execute(sql, params).fetchall()
        return {"dataset": dataset, "count": len(rows), "rows": [dict(row) for row in rows]}
    finally:
        connection.close()


def catalog_summary(data_dir: Path) -> dict[str, Any]:
    """Return an allowlisted metadata summary without exposing arbitrary SQL."""
    db_path = (data_dir / "catalog.sqlite3").resolve()
    if not db_path.exists():
        raise FileNotFoundError(f"catalog database not found: {db_path}")
    connection = sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True, timeout=2.0)
    try:
        project_count = connection.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        skill_count = connection.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
        return {"datasets": {"projects": project_count, "skills": skill_count}, "access": "read-only"}
    finally:
        connection.close()


def _tokens(text: str) -> list[str]:
    """Tokenize conservatively without a dependency on an NLP package."""
    current: list[str] = []
    output: list[str] = []
    for char in text:
        if char.isalnum() or char in "-_":
            current.append(char)
        elif current:
            output.append("".join(current))
            current = []
    if current:
        output.append("".join(current))
    return output


def json_for_log(payload: dict[str, Any]) -> str:
    """Serialize a small audit event; callers must not pass document contents or secrets."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))
