"""Secure, read-only MCP portfolio server."""

__version__ = "0.1.0"
