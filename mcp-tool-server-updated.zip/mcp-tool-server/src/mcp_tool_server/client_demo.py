"""Small MCP client that discovers tools and invokes a selected safe example."""

from __future__ import annotations

import asyncio
import json
import os
from typing import Any

from mcp import Client


async def run_demo() -> None:
    """Connect to a local Streamable HTTP server, list tools, and call calculate."""
    url = os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp")
    async with Client(url) as client:
        tools = await client.list_tools()
        print("Discovered tools:")
        for tool in tools.tools:
            print(f"- {tool.name}: {tool.description}")
        available = {tool.name for tool in tools.tools}
        if "calculate" not in available:
            raise RuntimeError("Server did not expose the expected 'calculate' tool")
        result: Any = await client.call_tool("calculate", {"expression": "(12 + 8) * 3"})
        print("\nCall result:")
        print(json.dumps(result.model_dump(mode="json"), indent=2, default=str))


def main() -> None:
    asyncio.run(run_demo())


if __name__ == "__main__":
    main()
