# MCP Tool Server

A small, security-conscious Model Context Protocol (MCP) server exposing document search, document metadata, safe arithmetic, and allowlisted read-only structured-data queries. It also demonstrates an MCP resource and prompt. The sample is local-first and needs no LLM API key.

> **Status:** MVP implementation. Core business-logic tests can run without the MCP SDK; protocol startup/client compatibility must be verified after installing the pinned SDK dependency. This project is not a remotely secured production service.

## Problem and intended users

AI applications need a standard way to discover tools and call them with structured inputs. This repository demonstrates an actual MCP server using the official Python SDK, rather than relabeling a REST API as MCP. It is intended for engineers learning AI infrastructure, tool integration, protocol testing, and least-privilege design.

## Features

- Official `mcp` Python SDK v2 API; Python 3.11+.
- `stdio` transport for local MCP hosts; optional Streamable HTTP bound to loopback.
- Tools: `search_documents_tool`, `get_document_metadata`, `calculate`, and `query_structured_data`.
- Resource: `catalog://summary`.
- Prompt: `research_documents`.
- Search over bundled Markdown files with source metadata.
- Safe arithmetic parser (AST allowlist; never uses `eval` or `exec`).
- SQLite catalog opened in read-only mode, allowlisted tables/columns, parameterized filter values, bounded results.
- Minimal audit logs that omit tool arguments and document content.
- A small MCP client demo for tool discovery and invocation.

## Non-goals

No autonomous agent, arbitrary SQL, shell execution, write operations, cloud deployment, remote authentication, multi-tenant authorization, embedding model, or paid LLM integration. The bundled document search is simple token-overlap ranking, not BM25 or semantic retrieval.

## Architecture

```mermaid
flowchart TD
    A[Compatible MCP host or demo client] -->|MCP over stdio or Streamable HTTP| B[Official MCP Python SDK]
    B --> C[Tool schemas and dispatch]
    C --> D[Document search and metadata]
    C --> E[Safe arithmetic parser]
    C --> F[Allowlisted catalog queries]
    D --> G[Bundled Markdown corpus]
    F --> H[(SQLite opened read-only)]
    B --> I[Resource: catalog summary]
    B --> J[Prompt: research documents]
```

## Prerequisites

- Python 3.11 or newer.
- `pip` or `uv`.
- Optional: Node.js and `npx` to run the MCP Inspector.

## Install

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

For reproducible installs, resolve dependencies in your environment and retain the generated lockfile if you use `uv`. The project bounds the official SDK to `mcp>=2.3.0,<3.0.0` to avoid silently crossing a major SDK API change.

## Run the server

### Local stdio transport

```bash
mcp-tool-server
```

The server stays attached to stdin/stdout for an MCP host. Do not use `print()` for server-side diagnostics; stdio is the protocol channel. Logs are written through Python logging.

### Streamable HTTP (loopback only)

```bash
MCP_TRANSPORT=streamable-http MCP_HOST=127.0.0.1 MCP_PORT=8000 mcp-tool-server
```

On Windows PowerShell:

```powershell
$env:MCP_TRANSPORT = "streamable-http"
$env:MCP_HOST = "127.0.0.1"
$env:MCP_PORT = "8000"
mcp-tool-server
```

The endpoint is `http://127.0.0.1:8000/mcp`. The app intentionally refuses non-loopback binding because remote authentication is not implemented. Do not expose this server to a network without adding and testing authentication, authorization, origin validation, rate limiting, and deployment controls.

## Try it with MCP Inspector

With the SDK CLI and Node.js installed:

```bash
mcp dev src/mcp_tool_server/server.py
```

Use the Inspector to list and call tools. If the installed CLI exposes a different invocation syntax, use the installed SDK's `mcp --help`; SDK tooling can change between releases.

## Compatible client demo

Start the server with Streamable HTTP in one terminal, then in another:

```bash
MCP_SERVER_URL=http://127.0.0.1:8000/mcp mcp-tool-client-demo
```

The demo calls `list_tools`, prints the tool names/descriptions, and invokes `calculate` with `(12 + 8) * 3`. This verifies discovery and invocation using an MCP client rather than direct Python function calls.

## Tool examples

`calculate` input:

```json
{"expression":"(12 + 8) * 3"}
```

Expected business result:

```json
{"expression":"(12 + 8) * 3","result":60}
```

`search_documents_tool` input:

```json
{"query":"MCP security read-only SQL","limit":3}
```

`query_structured_data` input:

```json
{"dataset":"projects","field":"domain","value":"ai-infrastructure","limit":10}
```

Only the `projects` and `skills` datasets and their documented fields are accepted. User-provided filter values are bound parameters. No tool accepts arbitrary SQL.

## Configuration

Copy `.env.example` as a reference; the application does not automatically load `.env` files. Set environment variables in the process or your host configuration:

| Variable | Default | Meaning |
|---|---|---|
| `MCP_SERVER_NAME` | `Portfolio MCP Tools` | Display name in the MCP server metadata |
| `MCP_DATA_DIR` | `data` | Directory containing the Markdown corpus and catalog database |
| `MCP_LOG_LEVEL` | `INFO` | Python logging level |
| `MCP_TRANSPORT` | `stdio` | `stdio` or `streamable-http` |
| `MCP_HOST` | `127.0.0.1` | HTTP bind address; loopback only |
| `MCP_PORT` | `8000` | HTTP port |
| `MCP_SERVER_URL` | `http://127.0.0.1:8000/mcp` | Demo client's server URL |

`MCP_DATA_DIR` is a local filesystem path and must be controlled by the operator, not supplied by an untrusted tool caller.

## Tests and quality checks

```bash
pytest -q
ruff check .
mypy src
```

Core tests cover search, metadata, unsafe calculator inputs, and allowlisted database queries. `tests/test_server_import.py` uses the official SDK in-memory client to verify tool discovery, a calculator invocation, resource listing, and prompt listing; it is skipped when the SDK is not installed. In this build environment, package-index DNS was unavailable, so protocol-level tests could not be executed here. After installing dependencies, run `pytest -q`, then run the Streamable HTTP client demo and MCP Inspector before marking protocol integration verified.

## Security and privacy

- No API keys or secrets are required.
- Tool arguments and returned document contents are not written to audit logs.
- Database access is read-only and uses an explicit table/column allowlist.
- Arithmetic is parsed with Python's AST and only approved numeric operations are evaluated.
- Document text is untrusted content; clients must not treat it as system instructions.
- Stdio is intended for a trusted local host. HTTP binds to loopback only by default and rejects external binding.
- There is no remote auth, tenant isolation, or application-level rate limiter in this MVP.
- Tool descriptions and annotations do not replace client-side review or user confirmation.

## Protocol and compatibility

The implementation targets the official Python SDK v2 API, with `MCPServer`, the SDK `Client`, and `stdio` / Streamable HTTP transports. The SDK supports protocol negotiation, but the exact protocol revision and compatible clients should be recorded from the installed SDK and tested host. Do not assume every MCP client supports every optional feature. See the official [Python SDK docs](https://py.sdk.modelcontextprotocol.io/) and [MCP tool specification](https://modelcontextprotocol.io/specification/2025-06-18/server/tools) for implementation details.

## Limitations and future improvements

1. Execute the new official in-memory client protocol tests after dependency installation; add a subprocess stdio test.
2. Add authentication and authorization before any non-local deployment.
3. Add request-level deadlines and per-client rate limits for hosted use.
4. Replace token overlap with a measured BM25 index if the corpus grows.
5. Add structured output schemas and compatibility tests for target clients.
6. Add audit-log rotation and a documented retention policy.

## Personal engineering contribution

When using this repository in a portfolio, describe only the work you personally understand and can reproduce: MCP capability design, input validation, read-only data access, safe arithmetic, transport setup, test coverage, and compatibility testing. Update this section with your actual changes before publication.

## License

MIT. The bundled synthetic data is described in `data/README.md`.
