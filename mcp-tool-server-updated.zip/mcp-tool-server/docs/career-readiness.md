# Career-readiness guide

## Target roles and skills

Relevant roles: AI Engineer, Generative AI Engineer, Applied AI Engineer, Agent/Tooling Engineer, and AI Platform Engineer. Demonstrated skills include MCP protocol concepts, tool schemas, client/server integration, Python type annotations, safe input handling, SQLite read-only access, testing, and transport trade-offs.

## Requirement-to-feature mapping

| Common requirement | Project evidence |
|---|---|
| Build an actual MCP server | Official `mcp` SDK server and transport entry point |
| Tool schemas and validation | Typed tool signatures and bounded business logic |
| Resources and prompts | `catalog://summary` and `research_documents` |
| Least privilege | Read-only SQLite, allowlisted datasets/fields, safe calculator |
| Client demonstration | Client calls `list_tools` and `call_tool` |
| Protocol tests | Inspector instructions and client demo; run these before claiming verified status |
| Operations/security | Minimal audit logs, loopback-only HTTP, threat model |

## Resume bullet templates

- Built an MCP server using the official Python SDK exposing **[verified number]** tools, **[verified number]** resources, and **[verified number]** prompts over **[tested transport]**.
- Implemented read-only structured-data access with an explicit table/field allowlist and parameterized queries; validated against **[number]** injection and invalid-input tests.
- Added client-based tool discovery and invocation plus CI checks, achieving **[measured test/CI outcome]** in a reproducible local environment.

Replace bracketed values only with verified results.

## Five-minute demo script

1. (0:00–0:45) Explain MCP: standard capability discovery and tool calls between a host and a server.
2. (0:45–1:30) Show the server's tools, resource, and prompt; explain type hints and generated schemas.
3. (1:30–2:30) Start Streamable HTTP on loopback and run the client demo to list tools and calculate `(12 + 8) * 3`.
4. (2:30–3:30) Query the synthetic project catalog; show allowlisted columns and read-only SQLite access.
5. (3:30–4:15) Demonstrate rejection of an unsafe calculator expression and invalid query fields.
6. (4:15–5:00) Discuss transport choices, remote-auth limitations, protocol testing, and next steps.

## Two-minute architecture explanation

"The official MCP SDK handles protocol messages and transport. The server exposes four bounded tools plus a resource and prompt. Tool handlers delegate to pure functions so business logic can be tested without starting a protocol server. Document search reads a small local corpus, the calculator interprets only an allowlisted arithmetic AST, and structured queries use a read-only SQLite connection with allowlisted table/field names and bound values. A separate client demonstrates capability discovery and invocation. HTTP is intentionally restricted to loopback because remote authentication is not implemented."

## Interview questions and model answers

1. **What problem does MCP solve?** It standardizes how AI hosts discover and invoke tools and access resources/prompts, reducing one-off integration code.
2. **How is MCP different from REST?** REST describes resource-oriented HTTP APIs; MCP defines protocol messages, capability discovery, and tools/resources/prompts. MCP can use stdio as well as HTTP transports.
3. **What is a tool?** A named callable capability with a description and typed input schema, invoked by a client.
4. **What is a resource?** A context/data endpoint identified by a URI, generally read by the client rather than used as an action.
5. **What is a prompt primitive?** A reusable prompt template exposed by the server for a client/user to retrieve and use.
6. **Why stdio?** It is simple for local hosts that launch a subprocess and avoids opening a network port; stdout must remain reserved for protocol traffic.
7. **Why Streamable HTTP?** It supports HTTP-connected clients and deployment scenarios; network exposure adds authentication, authorization, origin, and transport security requirements.
8. **Why not arbitrary SQL?** Model-generated SQL is untrusted and can leak data or mutate state. An allowlisted query API is easier to reason about and test.
9. **How is SQL injection reduced?** Table/field identifiers are allowlisted and filter values are passed as bound parameters. Identifiers cannot safely be supplied as bind parameters, so they are selected only from constants.
10. **How is calculator execution safe?** It parses the expression into an AST and recursively evaluates only numeric constants and specific arithmetic operators. Names, calls, attributes, and other nodes are rejected.
11. **What is prompt injection?** Untrusted content attempts to alter model behavior. Retrieved documents should be treated as data, and client-side policy must keep their instructions from overriding trusted instructions.
12. **Why keep core logic outside SDK decorators?** Pure functions are easier to unit-test, reuse, and audit without protocol setup.
13. **What should be logged?** Tool name, outcome, duration, and a correlation ID where available; avoid secrets, personal data, and full document contents.
14. **How would you authenticate remote clients?** Use an MCP-supported authorization design, validate issuer/audience/scopes, enforce per-tool authorization, use TLS at the edge, and test token expiry/revocation. This MVP does not implement that.
15. **How do you test protocol compatibility?** Connect with the official client and Inspector, verify list-tools/call-tool/resource/prompt operations, and test transport errors and invalid arguments.
16. **Why have a timeout?** Tool calls may hang due to I/O or resource exhaustion; bounded timeouts and cancellation prevent unbounded resource use. The current local file/SQLite calls are small; deployment-level limits remain future work.
17. **What are MCP server risks?** Overprivileged tools, malicious inputs, prompt injection, tool output trust, auth mistakes, and data leakage.
18. **What is least privilege here?** Tools can read only the bundled catalog and document corpus; no write tools or shell execution are exposed.
19. **Why does the SDK version matter?** Major releases can change server/client APIs; dependency bounds and compatibility tests prevent accidental API drift.
20. **What would you improve next?** Add SDK-level in-memory and subprocess integration tests, authentication for remote deployments, rate limits, and richer structured output schemas.

## Five debugging/system-design scenarios

1. **Client sees no tools:** check transport URL/path, server logs on stderr, SDK version, and whether the server process is alive; use Inspector to isolate client configuration.
2. **stdio client hangs:** ensure the server is not printing startup banners to stdout, check that the host launches the correct command, and confirm both sides use compatible SDK/protocol versions.
3. **Unexpected SQL results:** verify allowed dataset/field, bound value semantics, case-insensitive comparison, and seed-data version; never debug by enabling arbitrary SQL.
4. **Calculator accepts a dangerous expression:** add a regression test for the AST node type, fail closed for unknown nodes, and never fall back to `eval`.
5. **Need remote access for a team:** define identity, scopes, per-tool authorization, TLS, origin controls, audit retention, and rate limits before changing the loopback binding.

## Likely objections and honest answers

- **"Is this production-ready?"** No. It is a local-first learning MVP. Remote auth, rate limiting, and full operational hardening are not implemented.
- **"Is document search semantic?"** No. It uses simple token overlap and is intended to demonstrate MCP integration, not retrieval quality.
- **"Have you tested the protocol?"** Only claim that after installing the SDK and running Inspector/client checks. Pure-core tests alone do not prove transport compatibility.
- **"Why no LLM?"** MCP standardizes the tool boundary; a client/host can choose its own model. This demo keeps the server testable without a paid provider.
