# Acceptance criteria

- [x] Official MCP SDK server entry point and real MCP tools are defined.
- [x] Exposes document search, metadata lookup, arithmetic, and read-only catalog query tools.
- [x] Exposes one resource and one prompt.
- [x] Structured-data queries use a fixed allowlist and parameterized values.
- [x] Calculator does not use `eval` or `exec` and rejects calls/names.
- [x] HTTP mode is loopback-only unless security design is extended.
- [x] Bundled synthetic data and documented licensing are included.
- [x] Pure business-logic tests are included.
- [x] Compatible MCP client demonstration is included.
- [ ] Official SDK installation succeeds in the target environment.
- [ ] MCP Inspector discovery and tool invocation are verified.
- [ ] Client demo successfully connects to a running server.
- [ ] Ruff and mypy pass in the target environment.
- [ ] GitHub Actions workflow passes on GitHub.
- [ ] Repository has been reviewed and published by the author.
