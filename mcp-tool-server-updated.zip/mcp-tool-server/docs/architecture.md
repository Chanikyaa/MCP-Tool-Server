# Architecture and data flow

## Boundaries

- **Protocol boundary:** the official MCP SDK handles MCP framing, tool discovery, schema generation from type annotations, transport, and dispatch.
- **Application boundary:** `server.py` maps MCP tool calls to pure functions in `core.py`, catches expected validation/data errors, and emits minimal audit events.
- **Data boundary:** local Markdown is searched without network calls. The SQLite catalog is opened with `mode=ro`; only predefined tables and columns are selectable.
- **Client boundary:** `client_demo.py` is a separate MCP client that discovers tools and calls one tool over Streamable HTTP.

## Threats and mitigations

| Threat | Mitigation | Remaining limitation |
|---|---|---|
| SQL injection | Allowlisted dataset/field names and bound values | Catalog schema must remain operator-controlled |
| Arbitrary code execution | AST allowlist; no `eval` or `exec` | Resource exhaustion still needs deployment-level controls |
| Prompt injection in documents | Prompt tells client to treat retrieved text as untrusted | A consuming LLM client must enforce this instruction |
| Sensitive data in logs | Log tool name and status only | Infrastructure logs may need separate retention controls |
| Accidental network exposure | HTTP binding restricted to loopback | No remote auth or TLS implementation |
| Oversized requests | Query, expression, result, and file size bounds | Add host-level request limits for remote deployments |

## Data flow

1. MCP client requests capability discovery.
2. The SDK exposes schemas derived from type hints and docstrings.
3. The client invokes a tool with structured arguments.
4. The server validates inputs in the business-logic layer.
5. The tool accesses only the bundled documents or the read-only allowlisted SQLite catalog.
6. The result is returned via MCP; audit logs contain tool name and outcome only.
